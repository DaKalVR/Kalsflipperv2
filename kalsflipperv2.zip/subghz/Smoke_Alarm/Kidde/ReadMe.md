[Source](https://gist.github.com/vrillusions/74d537739558cca82c06c6d1a7ac77c2) / [Original Post](https://www.reddit.com/r/flipperzero/comments/10msnzu/time_to_test_smoke_detectors/) / [Product](https://www.kidde.com/home-safety/en/us/products/fire-safety/smoke-alarms/rf-sm-dc/)

[Protocol exploration](https://github.com/tofurky/kidde_cc1101) - hardwork done, bruteforce possible?

Credit: vrillusions (thanks [h00die](https://github.com/h00die) for the PR!)
