Found this restaurant pager in a gas station in Northern Germany: https://ibells.de/ruf-sets/restaurant-rufsysteme/gaesteruf-system/gaesterufsystem-kundenrufsystem-zj-68-20-pagers

There seem to be two versions, one with a fixed number of 20 pagers and one with up to 999.

I captured three signals that only differ in the last byte so I wrote a small python script to create 256 different codes. Probably could be extended to support the 999 possible pagers mentioned in the manual: http://m.callingsys.com/download/zj-68_usermanual.pdf

Feel free to copy the playlist file to your playlist folder to send all codes or let me know if you know a better way to brute force this pager.
