# Hampton Bay Ceiling Fan Remote - UC7083T
All 16 different possibilities in DMX Order
- - -
## Dip Switch Diagram
![dip-switch](dip-switch-settings.png)