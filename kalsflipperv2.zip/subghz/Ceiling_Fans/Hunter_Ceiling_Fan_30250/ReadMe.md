Hunter ceiling fan remote UC7848T

https://forum.flipper.net/t/hunter-ceiling-fan-remote-freq-302-5/3062