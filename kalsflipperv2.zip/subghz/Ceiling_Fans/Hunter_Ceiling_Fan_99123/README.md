## Hunter ceiling fan

These are files for the universal Hunter ceiling fan remote in raw format (model 99123)

![remote](https://i.imgur.com/0G8kCp4.jpg)
