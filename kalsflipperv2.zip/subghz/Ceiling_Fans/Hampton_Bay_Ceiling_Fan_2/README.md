# Hampton Bay Ceiling Fan (303mhz)

Link to product:
https://www.amazon.com/Replacement-UC7083T-Hampton-Ceiling-Wireless/dp/B072QYD1J5
