# Harbor Breeze A25-TX015

Universal Remote for Harbor Breeze Ceiling Fans

FCC info
https://fccid.io/A25-TX015

Product listing
https://www.lowes.com/pd/Harbor-Breeze-3-Speed-Off-white-Handheld-Universal-Ceiling-Fan-Remote-Control/1000061713


Cool / Heat toggle reverses the direction of rotation
