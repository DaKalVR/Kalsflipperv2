# LPHUMEX 1C 15C 1668

Sub-GHz recordings from LPHUMEX 1C 15C 1668 Universal Ceiling Fan Remote kit.

Product listing:
https://www.amazon.com/Ceiling-Fan-Remote-Control-Universal/dp/B07VF3V52Y

Recorded with Flipper Zero.