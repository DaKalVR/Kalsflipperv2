 NO this WILL NOT open a Lexus, you CAN NOT "troll" Lexus owners and don't be that dick anyway.<br>
 This is to help somebody to decode a protocol to bruteforce them or for testing purposes.

FCC ID: [HYQ14FBA](https://fccid.io/HYQ14FBA)

Frequencies:<br>
312.1<br>
314.35

The fob seems to hop between 312 and 314 every other press.<br>
I have included 10x captures each for the 312 and 314 jumps.<br>
More info can be found at [this forum link](https://forum.flipperzero.one/t/2017-lexus-nx200t-keyfob/3786).
